<?
	//sleep(5);
	//unlink('../../'.$_GET['link']);
	echo 'ok';