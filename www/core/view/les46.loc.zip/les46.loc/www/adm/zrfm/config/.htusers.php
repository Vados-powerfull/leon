<?php 
	// ensure this file is being included by a parent file
	if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );
	$GLOBALS["users"]=array(
	array('admin','$2a$08$yYZ4FF9l/nkFcT8J/vmJiegjktXvOsRIZl5pk2TKXlZxWYgk/YeSG','/','http://slon.webzr.ru','1','','7',1),
); 
?>